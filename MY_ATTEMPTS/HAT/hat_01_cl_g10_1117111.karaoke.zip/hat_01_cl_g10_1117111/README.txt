Karaoke pack — hat_01_cl_g10_1117111
========================================
Audio:        hat_01_cl_g10_1117111.mp3
Lyrics:       hat_01_cl_g10_1117111.txt  (one sung line per line)
Word timings: hat_01_cl_g10_1117111.words.json  (source of truth)
Subtitles:    hat_01_cl_g10_1117111.srt / hat_01_cl_g10_1117111.vtt  (line level)
Player:       hat_01_cl_g10_1117111.player.html  (open in a browser; audio is bundled)

Alignment
  model:          akbargherbal/wav2vec2-large-xlsr-53-arabic @ 4ca1c9c6ac85
  words aligned:  139/139
  duration:       327.2 s
  line mapping:   line
  intro check:    ok
  coverage:       1.0
  monotone:       True

Warnings
  - 20 gaps > 2.0s (max 12.701s) -- skipped stretches
  - longest single word spans 14.601s (melisma, or a collapsed phrase)
  - repeat gate: 15 suspected extra rendition(s) on lyric line 44 ('عَمْيَاءُ...'); expand the text per render and re-align
