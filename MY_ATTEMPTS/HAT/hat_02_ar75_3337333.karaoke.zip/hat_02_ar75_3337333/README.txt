Karaoke pack — hat_02_ar75_3337333
========================================
Audio:        hat_02_ar75_3337333.mp3
Lyrics:       hat_02_ar75_3337333.txt  (one sung line per line)
Word timings: hat_02_ar75_3337333.words.json  (source of truth)
Subtitles:    hat_02_ar75_3337333.srt / hat_02_ar75_3337333.vtt  (line level)
Player:       hat_02_ar75_3337333.player.html  (open in a browser; audio is bundled)

Alignment
  model:          akbargherbal/wav2vec2-large-xlsr-53-arabic @ 4ca1c9c6ac85
  words aligned:  139/139
  duration:       337.6 s
  line mapping:   line
  intro check:    ok
  coverage:       0.966
  monotone:       True

Warnings
  - 15 gaps > 2.0s (max 18.641s) -- skipped stretches
  - longest single word spans 15.501s (melisma, or a collapsed phrase)
  - repeat gate: 17 suspected extra rendition(s) on lyric line 45 ('عَمْيَاءُ...'); expand the text per render and re-align
